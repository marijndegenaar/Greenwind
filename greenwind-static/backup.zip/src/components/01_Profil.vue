<template lang="pug">
  .inner
    include ../content/01_energy/01_profil.pug
</template>

<script>
  export default {
    name: 'profil'
  }
</script>

<style lang="sass" scoped>
	@import '../assets/sass/profil.sass'
</style>
