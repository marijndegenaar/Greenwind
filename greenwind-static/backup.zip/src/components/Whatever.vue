<template lang="pug">
  .inner
    include ../content/energy/01_profil.pug
</template>

<script>
  export default {
    name: 'whatever'
  }
</script>

<style lang="sass" scoped>
</style>
